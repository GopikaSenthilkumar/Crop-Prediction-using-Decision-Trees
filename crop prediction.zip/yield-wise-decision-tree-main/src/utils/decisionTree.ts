
import { CropType, SoilParameters, PredictionResult } from '../models/crop-prediction';

// A simple decision tree implementation for crop prediction
export function predictCrop(params: SoilParameters): PredictionResult[] {
  const results: PredictionResult[] = [];
  
  // Calculate suitability scores for each crop
  // This is a simplified version of a decision tree algorithm
  
  // Rice conditions
  if (params.rainfall > 200 && params.humidity > 80 && params.ph >= 5.5 && params.ph <= 7.5) {
    results.push({
      crop: "rice",
      confidence: calculateConfidence(params, {
        nitrogen: 80, phosphorus: 40, potassium: 40, 
        temperature: 25, humidity: 85, ph: 6.5, rainfall: 250
      }),
      recommendation: "Rice thrives in your soil conditions. Ensure proper irrigation and field leveling."
    });
  }
  
  // Maize conditions
  if (params.temperature >= 20 && params.temperature <= 30 && params.rainfall >= 80 && params.rainfall <= 200) {
    results.push({
      crop: "maize",
      confidence: calculateConfidence(params, {
        nitrogen: 80, phosphorus: 60, potassium: 40, 
        temperature: 24, humidity: 65, ph: 6.2, rainfall: 120
      }),
      recommendation: "Maize is suitable for your conditions. Consider proper spacing and regular weeding."
    });
  }
  
  // Cotton conditions
  if (params.temperature > 25 && params.rainfall >= 80 && params.rainfall <= 150) {
    results.push({
      crop: "cotton",
      confidence: calculateConfidence(params, {
        nitrogen: 100, phosphorus: 50, potassium: 50, 
        temperature: 28, humidity: 60, ph: 6.8, rainfall: 100
      }),
      recommendation: "Cotton will grow well. Implement pest management for bollworms."
    });
  }
  
  // Apple conditions
  if (params.temperature >= 15 && params.temperature <= 24 && params.ph >= 5.5 && params.ph <= 6.5) {
    results.push({
      crop: "apple",
      confidence: calculateConfidence(params, {
        nitrogen: 70, phosphorus: 45, potassium: 70, 
        temperature: 20, humidity: 70, ph: 6.0, rainfall: 150
      }),
      recommendation: "Apple trees would do well. Consider adequate chilling hours for your variety."
    });
  }
  
  // Orange conditions
  if (params.temperature >= 15 && params.temperature <= 30 && params.ph >= 5.5 && params.ph <= 7.0) {
    results.push({
      crop: "orange",
      confidence: calculateConfidence(params, {
        nitrogen: 60, phosphorus: 45, potassium: 60, 
        temperature: 25, humidity: 60, ph: 6.2, rainfall: 120
      }),
      recommendation: "Oranges can thrive. Ensure proper pruning and pest management."
    });
  }
  
  // Mango conditions
  if (params.temperature > 24 && params.rainfall >= 80 && params.rainfall <= 200 && params.humidity < 80) {
    results.push({
      crop: "mango",
      confidence: calculateConfidence(params, {
        nitrogen: 50, phosphorus: 50, potassium: 80, 
        temperature: 28, humidity: 65, ph: 6.5, rainfall: 130
      }),
      recommendation: "Mangoes will grow well. Protect from frost during early stages."
    });
  }
  
  // Banana conditions
  if (params.temperature > 24 && params.rainfall > 120 && params.ph >= 6.0 && params.ph <= 7.5) {
    results.push({
      crop: "banana",
      confidence: calculateConfidence(params, {
        nitrogen: 100, phosphorus: 75, potassium: 100, 
        temperature: 27, humidity: 80, ph: 6.5, rainfall: 200
      }),
      recommendation: "Bananas are ideal for your conditions. Consider windbreaks to protect plants."
    });
  }
  
  // Grapes conditions
  if (params.temperature >= 15 && params.temperature <= 30 && params.rainfall >= 40 && params.rainfall <= 130) {
    results.push({
      crop: "grapes",
      confidence: calculateConfidence(params, {
        nitrogen: 50, phosphorus: 50, potassium: 80, 
        temperature: 23, humidity: 60, ph: 6.3, rainfall: 80
      }),
      recommendation: "Grapes can do well. Ensure proper trellising and pruning."
    });
  }
  
  // Watermelon conditions
  if (params.temperature > 24 && params.rainfall >= 50 && params.rainfall <= 150) {
    results.push({
      crop: "watermelon",
      confidence: calculateConfidence(params, {
        nitrogen: 60, phosphorus: 60, potassium: 80, 
        temperature: 28, humidity: 65, ph: 6.2, rainfall: 90
      }),
      recommendation: "Watermelons are suitable. Consider mulching and proper spacing."
    });
  }
  
  // Lentil conditions
  if (params.temperature >= 15 && params.temperature <= 25 && params.rainfall >= 40 && params.rainfall <= 120) {
    results.push({
      crop: "lentil",
      confidence: calculateConfidence(params, {
        nitrogen: 40, phosphorus: 60, potassium: 40, 
        temperature: 20, humidity: 55, ph: 6.5, rainfall: 70
      }),
      recommendation: "Lentils are suitable. Ensure proper drainage and weed control."
    });
  }
  
  // Coffee conditions
  if (params.temperature >= 15 && params.temperature <= 28 && params.rainfall >= 150 && params.rainfall <= 250 && params.ph >= 5.0 && params.ph <= 6.5) {
    results.push({
      crop: "coffee",
      confidence: calculateConfidence(params, {
        nitrogen: 60, phosphorus: 40, potassium: 80, 
        temperature: 22, humidity: 75, ph: 5.5, rainfall: 180
      }),
      recommendation: "Coffee would grow well. Consider shade management and proper pruning."
    });
  }
  
  // Default fallback
  if (results.length === 0) {
    results.push({
      crop: "maize",
      confidence: 0.5,
      recommendation: "Based on limited matching criteria, maize might be an option, but consider soil amendments and proper management practices."
    });
  }
  
  // Sort by confidence level
  return results.sort((a, b) => b.confidence - a.confidence);
}

// Calculate confidence score based on how close the parameters are to ideal conditions
function calculateConfidence(actual: SoilParameters, ideal: SoilParameters): number {
  // Calculate normalized distance for each parameter
  const nDist = (
    normalizedDistance(actual.nitrogen, ideal.nitrogen, 0, 140) +
    normalizedDistance(actual.phosphorus, ideal.phosphorus, 0, 140) +
    normalizedDistance(actual.potassium, ideal.potassium, 0, 140) +
    normalizedDistance(actual.temperature, ideal.temperature, 10, 40) +
    normalizedDistance(actual.humidity, ideal.humidity, 30, 100) +
    normalizedDistance(actual.ph, ideal.ph, 4, 10) +
    normalizedDistance(actual.rainfall, ideal.rainfall, 20, 300)
  ) / 7; // Average over 7 parameters
  
  // Convert distance to confidence (0-1 scale)
  return Math.max(0, Math.min(1, 1 - nDist));
}

// Calculate normalized distance between actual and ideal values
function normalizedDistance(actual: number, ideal: number, min: number, max: number): number {
  // Normalize both values to 0-1 scale
  const normalizedActual = (actual - min) / (max - min);
  const normalizedIdeal = (ideal - min) / (max - min);
  
  // Calculate absolute distance
  return Math.abs(normalizedActual - normalizedIdeal);
}

// Function to generate decision path explanation
export function generateDecisionPath(params: SoilParameters, result: PredictionResult): string[] {
  const path: string[] = [];
  
  // Generate path based on the crop and parameters
  switch (result.crop) {
    case "rice":
      path.push("Your soil has sufficient nitrogen content");
      path.push("Rainfall levels above 200mm are ideal for rice");
      path.push("High humidity levels favor rice cultivation");
      path.push("pH level in the neutral range supports rice growth");
      break;
    case "maize":
      path.push("The temperature range is suitable for maize");
      path.push("Moderate rainfall levels support maize growth");
      path.push("The soil's NPK balance favors maize cultivation");
      break;
    case "cotton":
      path.push("High temperature favors cotton growth");
      path.push("Moderate rainfall is ideal for cotton");
      path.push("The soil has good potassium content for fiber development");
      break;
    case "apple":
      path.push("The cool to moderate temperature range is ideal for apples");
      path.push("Slightly acidic soil pH supports apple trees");
      path.push("Balanced NPK levels support fruit development");
      break;
    // Add more cases for other crops
    default:
      path.push("The soil parameters have been analyzed");
      path.push("Based on multiple factors, this crop has been recommended");
      path.push("The confidence level indicates how well your conditions match the ideal");
  }
  
  return path;
}
