
import React, { useState } from 'react';
import { SoilParameters, PredictionResult } from '@/models/crop-prediction';
import { predictCrop } from '@/utils/decisionTree';
import PredictionForm from '@/components/PredictionForm';
import PredictionResults from '@/components/PredictionResults';
import DecisionTreeViz from '@/components/DecisionTreeViz';
import Footer from '@/components/Footer';
import { useToast } from "@/components/ui/use-toast";

const Index = () => {
  const [results, setResults] = useState<PredictionResult[]>([]);
  const [selectedParameters, setSelectedParameters] = useState<SoilParameters | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handlePredict = (params: SoilParameters) => {
    setIsLoading(true);
    
    // Simulate processing time
    setTimeout(() => {
      try {
        const predictionResults = predictCrop(params);
        setResults(predictionResults);
        setSelectedParameters(params);
        
        toast({
          title: "Prediction Complete",
          description: `Found ${predictionResults.length} suitable crops based on your parameters.`,
          variant: "default",
        });
      } catch (error) {
        console.error("Prediction error:", error);
        toast({
          title: "Prediction Error",
          description: "An error occurred while analyzing your data. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero section */}
      <header className="bg-gradient-to-br from-leaf-800 to-leaf-900 text-white py-12 md:py-20">
        <div className="container px-4 mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">CropWise</h1>
          <p className="text-xl md:text-2xl text-leaf-100 max-w-2xl mx-auto">
            Intelligent crop recommendations using decision tree algorithms
          </p>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow container px-4 mx-auto py-8">
        <div className="max-w-4xl mx-auto mb-12">
          <div className="bg-leaf-50 rounded-lg p-6 border border-leaf-200 mb-8">
            <h2 className="text-2xl font-bold text-leaf-800 mb-2">How It Works</h2>
            <p className="text-gray-700">
              Our prediction system analyzes your soil composition and climate conditions using decision tree algorithms
              to recommend the most suitable crops for your farm. Simply input your parameters using the sliders below
              and get instant recommendations.
            </p>
          </div>

          <PredictionForm onPredict={handlePredict} isLoading={isLoading} />
        </div>

        {results.length > 0 && selectedParameters && (
          <div className="max-w-5xl mx-auto">
            <div className="mb-12">
              <PredictionResults results={results} />
            </div>
            
            <div className="mb-12">
              <DecisionTreeViz params={selectedParameters} result={results[0]} />
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default Index;
