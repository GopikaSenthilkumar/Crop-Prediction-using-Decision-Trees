
// Define input parameters for crop prediction
export interface SoilParameters {
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  temperature: number;
  humidity: number;
  ph: number;
  rainfall: number;
}

// Results type for crop prediction
export interface PredictionResult {
  crop: CropType;
  confidence: number;
  recommendation: string;
}

// Define crop types
export type CropType = 
  | "rice" 
  | "maize" 
  | "jute" 
  | "cotton" 
  | "coconut" 
  | "papaya" 
  | "orange" 
  | "apple" 
  | "muskmelon" 
  | "watermelon" 
  | "grapes" 
  | "mango" 
  | "banana" 
  | "pomegranate" 
  | "lentil" 
  | "blackgram" 
  | "mungbean" 
  | "mothbeans" 
  | "pigeonpeas" 
  | "kidneybeans" 
  | "chickpea" 
  | "coffee";

// Define crop information
export interface CropInfo {
  name: CropType;
  description: string;
  idealConditions: string;
  icon: string;
}

// Crop database with information
export const cropDatabase: Record<CropType, CropInfo> = {
  rice: {
    name: "rice",
    description: "A staple food crop that thrives in wet conditions with high rainfall.",
    idealConditions: "High rainfall, high humidity, neutral pH",
    icon: "🌾"
  },
  maize: {
    name: "maize",
    description: "Also known as corn, it's a versatile crop used for food, feed, and fuel.",
    idealConditions: "Moderate temperature, moderate rainfall, slightly acidic soil",
    icon: "🌽"
  },
  jute: {
    name: "jute",
    description: "A fiber crop used to make burlap and other textiles.",
    idealConditions: "High temperature, high rainfall, neutral pH",
    icon: "🧵"
  },
  cotton: {
    name: "cotton",
    description: "A soft, fluffy fiber that grows in a protective case around the seeds.",
    idealConditions: "High temperature, moderate rainfall, neutral pH",
    icon: "🧶"
  },
  coconut: {
    name: "coconut",
    description: "A tropical tree with multiple uses including food, fiber, and fuel.",
    idealConditions: "High temperature, high rainfall, sandy soil",
    icon: "🥥"
  },
  papaya: {
    name: "papaya",
    description: "A tropical fruit with orange flesh and black seeds.",
    idealConditions: "High temperature, moderate rainfall, well-drained soil",
    icon: "🍈"
  },
  orange: {
    name: "orange",
    description: "A citrus fruit high in vitamin C.",
    idealConditions: "Moderate temperature, moderate rainfall, slightly acidic soil",
    icon: "🍊"
  },
  apple: {
    name: "apple",
    description: "A popular fruit that grows in temperate regions.",
    idealConditions: "Cool temperature, moderate rainfall, slightly acidic soil",
    icon: "🍎"
  },
  muskmelon: {
    name: "muskmelon",
    description: "A sweet fruit with orange flesh and a netted rind.",
    idealConditions: "High temperature, moderate rainfall, well-drained soil",
    icon: "🍈"
  },
  watermelon: {
    name: "watermelon",
    description: "A large fruit with sweet, juicy red flesh.",
    idealConditions: "High temperature, moderate rainfall, sandy soil",
    icon: "🍉"
  },
  grapes: {
    name: "grapes",
    description: "Small berries that grow in clusters on vines.",
    idealConditions: "Moderate temperature, low rainfall, well-drained soil",
    icon: "🍇"
  },
  mango: {
    name: "mango",
    description: "A tropical fruit with sweet, orange flesh.",
    idealConditions: "High temperature, moderate rainfall, well-drained soil",
    icon: "🥭"
  },
  banana: {
    name: "banana",
    description: "A long, curved fruit with a soft, sweet flesh.",
    idealConditions: "High temperature, high rainfall, well-drained soil",
    icon: "🍌"
  },
  pomegranate: {
    name: "pomegranate",
    description: "A fruit with red seeds called arils inside a leathery skin.",
    idealConditions: "Hot and dry climate, moderate rainfall, well-drained soil",
    icon: "🍑"
  },
  lentil: {
    name: "lentil",
    description: "A legume with lens-shaped seeds used in soups and stews.",
    idealConditions: "Cool temperature, low rainfall, well-drained soil",
    icon: "🫘"
  },
  blackgram: {
    name: "blackgram",
    description: "A pulse crop that's an important source of protein.",
    idealConditions: "Moderate temperature, moderate rainfall, well-drained soil",
    icon: "🫘"
  },
  mungbean: {
    name: "mungbean",
    description: "A small green bean used in Asian cuisine.",
    idealConditions: "Warm temperature, moderate rainfall, well-drained soil",
    icon: "🫘"
  },
  mothbeans: {
    name: "mothbeans",
    description: "A drought-resistant legume grown in arid regions.",
    idealConditions: "High temperature, low rainfall, well-drained soil",
    icon: "🫘"
  },
  pigeonpeas: {
    name: "pigeonpeas",
    description: "A tropical legume also known as red gram or toor dal.",
    idealConditions: "High temperature, moderate rainfall, well-drained soil",
    icon: "🫘"
  },
  kidneybeans: {
    name: "kidneybeans",
    description: "Red beans shaped like kidneys used in many cuisines.",
    idealConditions: "Moderate temperature, moderate rainfall, well-drained soil",
    icon: "🫘"
  },
  chickpea: {
    name: "chickpea",
    description: "A versatile legume also known as garbanzo beans.",
    idealConditions: "Cool temperature, low rainfall, well-drained soil",
    icon: "🫘"
  },
  coffee: {
    name: "coffee",
    description: "A tropical crop that produces beans for the popular beverage.",
    idealConditions: "Moderate temperature, moderate rainfall, well-drained soil",
    icon: "☕"
  }
};
