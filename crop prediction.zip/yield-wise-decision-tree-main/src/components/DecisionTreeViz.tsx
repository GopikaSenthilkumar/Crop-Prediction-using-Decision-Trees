
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SoilParameters, PredictionResult } from '@/models/crop-prediction';
import { generateDecisionPath } from '@/utils/decisionTree';

interface DecisionTreeVizProps {
  params: SoilParameters;
  result: PredictionResult;
}

const DecisionTreeViz: React.FC<DecisionTreeVizProps> = ({ params, result }) => {
  const decisionPath = generateDecisionPath(params, result);

  if (!params || !result) {
    return null;
  }

  return (
    <Card className="border-none shadow-sm bg-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl text-leaf-700">Decision Path Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative pl-8 py-2">
          {/* Vertical line */}
          <div className="absolute top-0 left-3 w-0.5 h-full bg-leaf-200" />

          {decisionPath.map((step, index) => (
            <div key={index} className="relative mb-6 last:mb-0">
              {/* Node circle */}
              <div className="absolute -left-6 mt-1 w-6 h-6 rounded-full bg-leaf-500 flex items-center justify-center text-white text-xs border-2 border-white">
                {index + 1}
              </div>
              
              {/* Content */}
              <div className="bg-white p-3 rounded-lg border border-leaf-100 shadow-sm">
                <p className="text-sm text-leaf-800">{step}</p>
              </div>

              {/* Arrow pointing down if not the last item */}
              {index < decisionPath.length - 1 && (
                <div className="absolute -left-3 bottom-0 transform translate-y-3">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6 0V12M6 12L1 7M6 12L11 7" stroke="#4a944a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              )}
            </div>
          ))}

          {/* Final node with result */}
          <div className="relative">
            <div className="absolute -left-8 mt-1 w-10 h-10 rounded-full bg-leaf-700 flex items-center justify-center text-white text-sm border-2 border-white animate-pulse-grow">
              ✓
            </div>
            
            <div className="bg-gradient-to-r from-leaf-50 to-white p-3 rounded-lg border border-leaf-200 shadow-sm">
              <p className="text-sm font-medium text-leaf-800">
                Final prediction: <span className="font-bold text-leaf-700">{result.crop.charAt(0).toUpperCase() + result.crop.slice(1)}</span> with {Math.round(result.confidence * 100)}% confidence
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DecisionTreeViz;
