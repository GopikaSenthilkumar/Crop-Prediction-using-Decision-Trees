
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { SoilParameters } from '@/models/crop-prediction';

interface PredictionFormProps {
  onPredict: (params: SoilParameters) => void;
  isLoading: boolean;
}

const PredictionForm: React.FC<PredictionFormProps> = ({ onPredict, isLoading }) => {
  const [params, setParams] = useState<SoilParameters>({
    nitrogen: 40,
    phosphorus: 40,
    potassium: 40,
    temperature: 25,
    humidity: 60,
    ph: 6.5,
    rainfall: 100
  });

  const handleSliderChange = (name: keyof SoilParameters, value: number[]) => {
    setParams(prev => ({
      ...prev,
      [name]: value[0]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPredict(params);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-6 bg-white rounded-lg shadow-md leaf-pattern">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-leaf-700">Soil & Climate Parameters</h2>
        <p className="text-muted-foreground">Adjust the sliders to match your conditions</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="nitrogen" className="text-sm font-medium">
              Nitrogen (N)
            </Label>
            <span className="text-sm font-medium">{params.nitrogen} mg/kg</span>
          </div>
          <Slider
            id="nitrogen"
            min={0}
            max={140}
            step={1}
            value={[params.nitrogen]}
            onValueChange={(value) => handleSliderChange('nitrogen', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Essential for leaf growth and green vegetation</p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="phosphorus" className="text-sm font-medium">
              Phosphorus (P)
            </Label>
            <span className="text-sm font-medium">{params.phosphorus} mg/kg</span>
          </div>
          <Slider
            id="phosphorus"
            min={0}
            max={140}
            step={1}
            value={[params.phosphorus]}
            onValueChange={(value) => handleSliderChange('phosphorus', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Important for root development and flowering</p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="potassium" className="text-sm font-medium">
              Potassium (K)
            </Label>
            <span className="text-sm font-medium">{params.potassium} mg/kg</span>
          </div>
          <Slider
            id="potassium"
            min={0}
            max={140}
            step={1}
            value={[params.potassium]}
            onValueChange={(value) => handleSliderChange('potassium', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Enhances overall plant health and disease resistance</p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="temperature" className="text-sm font-medium">
              Temperature
            </Label>
            <span className="text-sm font-medium">{params.temperature}°C</span>
          </div>
          <Slider
            id="temperature"
            min={10}
            max={40}
            step={0.1}
            value={[params.temperature]}
            onValueChange={(value) => handleSliderChange('temperature', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Average temperature during growing season</p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="humidity" className="text-sm font-medium">
              Humidity
            </Label>
            <span className="text-sm font-medium">{params.humidity}%</span>
          </div>
          <Slider
            id="humidity"
            min={30}
            max={100}
            step={1}
            value={[params.humidity]}
            onValueChange={(value) => handleSliderChange('humidity', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Average relative humidity in the air</p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="ph" className="text-sm font-medium">
              Soil pH
            </Label>
            <span className="text-sm font-medium">{params.ph}</span>
          </div>
          <Slider
            id="ph"
            min={4}
            max={10}
            step={0.1}
            value={[params.ph]}
            onValueChange={(value) => handleSliderChange('ph', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Acidity/alkalinity of the soil (7 is neutral)</p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label htmlFor="rainfall" className="text-sm font-medium">
              Rainfall
            </Label>
            <span className="text-sm font-medium">{params.rainfall} mm</span>
          </div>
          <Slider
            id="rainfall"
            min={20}
            max={300}
            step={1}
            value={[params.rainfall]}
            onValueChange={(value) => handleSliderChange('rainfall', value)}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">Average rainfall during the growing season</p>
        </div>
      </div>

      <div className="pt-4">
        <Button 
          type="submit" 
          className="w-full bg-leaf-600 hover:bg-leaf-700 text-white py-2"
          disabled={isLoading}
        >
          {isLoading ? "Analyzing Soil Data..." : "Predict Suitable Crops"}
        </Button>
      </div>
    </form>
  );
};

export default PredictionForm;
