
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PredictionResult, cropDatabase } from '@/models/crop-prediction';

interface PredictionResultsProps {
  results: PredictionResult[];
}

const PredictionResults: React.FC<PredictionResultsProps> = ({ results }) => {
  if (!results || results.length === 0) {
    return null;
  }

  const topResult = results[0];
  const otherResults = results.slice(1, 4); // Show up to 3 additional results

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-leaf-700">Crop Prediction Results</h2>
        <p className="text-muted-foreground">Based on your soil and climate parameters</p>
      </div>

      {/* Top recommendation */}
      <Card className="border-2 border-leaf-500 bg-gradient-to-br from-white to-leaf-50">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <Badge variant="outline" className="bg-leaf-100 text-leaf-800 text-sm">
              Top Recommendation
            </Badge>
            <div className="text-4xl" aria-hidden="true">
              {cropDatabase[topResult.crop].icon}
            </div>
          </div>
          <CardTitle className="text-2xl text-leaf-800 mt-2 flex items-center gap-2">
            {cropDatabase[topResult.crop].name.charAt(0).toUpperCase() + cropDatabase[topResult.crop].name.slice(1)}
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            {cropDatabase[topResult.crop].description}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Confidence</span>
              <span className="font-medium">{Math.round(topResult.confidence * 100)}%</span>
            </div>
            <Progress value={topResult.confidence * 100} className="h-2" />
          </div>
          
          <div className="bg-leaf-50 p-3 rounded-md border border-leaf-100">
            <h4 className="font-medium text-leaf-800 mb-1">Recommendation:</h4>
            <p className="text-sm">{topResult.recommendation}</p>
          </div>
          
          <div className="bg-sky-50 p-3 rounded-md border border-sky-100">
            <h4 className="font-medium text-sky-800 mb-1">Ideal Growing Conditions:</h4>
            <p className="text-sm">{cropDatabase[topResult.crop].idealConditions}</p>
          </div>
        </CardContent>
      </Card>

      {/* Alternative options */}
      {otherResults.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold mb-3 text-leaf-700">Alternative Options</h3>
          <div className="grid gap-4 md:grid-cols-3">
            {otherResults.map((result, index) => (
              <Card key={index} className="bg-white">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <span className="text-3xl" aria-hidden="true">
                      {cropDatabase[result.crop].icon}
                    </span>
                    <Badge variant="outline" className="bg-secondary text-secondary-foreground text-xs">
                      {Math.round(result.confidence * 100)}% match
                    </Badge>
                  </div>
                  <CardTitle className="text-lg mt-2">
                    {result.crop.charAt(0).toUpperCase() + result.crop.slice(1)}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm">
                  <p className="line-clamp-2">{cropDatabase[result.crop].description}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <p className="text-xs text-muted-foreground italic">
                    {cropDatabase[result.crop].idealConditions}
                  </p>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionResults;
